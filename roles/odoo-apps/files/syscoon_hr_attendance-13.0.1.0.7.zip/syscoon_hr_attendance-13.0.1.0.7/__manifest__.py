# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Attendance and Overtime Management',
    'version': '13.0.1.0.7',

    'category': 'Human Resources',
    'images': ['static/description/HrAttendance.png'],
    'sequence': 81,
    'summary': 'Track employee attendance and Overtime',
    'license': "LGPL-3",
    'description': """
This module aims to manage employee's attendances and Overtime Calculations.
==================================================

Keeps account of the attendances of the employees on the basis of the
actions(Check in/Check out) performed by them.
       """,
    'author': 'syscoon GmbH',
    'website': 'https://syscoon.com',
    'depends': ['hr_holidays','hr_attendance'],
    'data': [
        'security/ir.model.access.csv',
        'security/hr_attendance_security.xml',
        'data/ir_cron.xml',
        'views/hr_missed_attendance_view.xml',
        'views/hr_attendance_view.xml',
        'views/res_config_settings_views.xml',
        'views/hr_employee_views.xml',
        'views/resource_views.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
    'qweb': [
    ],
    'application': True,
}
