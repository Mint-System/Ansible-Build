# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, exceptions, _
from datetime import datetime, time, timedelta, date
from dateutil.relativedelta import relativedelta
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from pytz import timezone, UTC
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
import math


class HrAttendance(models.Model):
    _inherit = "hr.attendance"
    _description = "Attendance"
    _order = 'check_in desc'

    expect_time = fields.Float('Expected', compute='_compute_time', store=True, help="Zu leistende Tages-Arbeitszeit")
    add_expect_time = fields.Float('Additional Expected',
                                   help="Manuell Anpassung der zu leistenden Arbeitszeit am Tag des Eintrages")

    legal_worked_time = fields.Float('Legal Worked Time', compute='_compute_time', store=True,
                                     help="Geleistete Arbeitszeit abzüglich gesetzlicher Pausen")
    factor_time = fields.Float('Factor Time', compute='_compute_time', store=True,
                               help="Factor Time = ( (Factor -1) * Legal Worked Time)")
    over_time_record = fields.Float('Overtime (Record)', compute='_compute_time', store=True,
                                    help="Geleistete Überstunden in diesem Eintrag – inkl. virtuellen Überstunden die durch einen erhöhten Stundensatz (Faktor) für bestimmte Zeiträume zustandekommen.\n Overtime (Record)= Overtime (Day) + Factor Time")

    over_time_real = fields.Float('Overtime (Real)', compute='_compute_time', store=True,
                                  help="Tatsächlich geleistete Überstunden")
    legal_break = fields.Float('Legal break ', compute='_compute_time', store=True)
    absences = fields.Float(string='Absences', readonly=True, store=True, compute='_compute_time')

    actual_time_daily_worked = fields.Float('Actual Worked Time Daily', compute='_compute_cumulative_time', store=True)
    legal_worked_time_day = fields.Float('Legal Worked Time (Day)', compute='_compute_cumulative_time', store=True,
                                         help="Geleistete Arbeitszeit abzüglich gesetzlicher Pausen")
    factor_time_day = fields.Float('Factor Time (Day)', compute='_compute_cumulative_time', store=True,
                                   help="Factor Time = ( (Factor -1) * Legal Worked Time)")
    over_time_record_day = fields.Float('Overtime (Record:Day)', compute='_compute_cumulative_time', store=True,
                                        help="Geleistete Überstunden in diesem Eintrag – inkl. virtuellen Überstunden die durch einen erhöhten Stundensatz (Faktor) für bestimmte Zeiträume zustandekommen.\n Overtime (Record)= Overtime (Day) + Factor Time")
    over_time_history = fields.Float('Overtime (History)', compute='_compute_cumulative_time', store=True,
                                     help="Aktueller Stand der insgesamt geleisteten Überstunden – inkl. virtuellen Überstunden die durch einen erhöhten Stundensatz (Faktor) für bestimmte Zeiträume zustandekommen. Der aktuellste Eintrag in der Liste ist der gültige IST Zustand.")
    over_time_day = fields.Float('Overtime (Day)', compute='_compute_cumulative_time', store=True,
                                 help="Geleistete Überstunden für den Tag dieses Eintrages – inkl. virtuellen Überstunden die durch einen erhöhten Stundensatz (Faktor) für bestimmte Zeiträume zustandekommen. Der aktuellste Eintrag in der Liste ist der gültige IST Zustand.")
    manual_break = fields.Float('Manual break ', compute='_compute_cumulative_time', store=True)

    holiday_status = fields.Char(string='Reason for Absence', readonly=True, compute='_compute_holiday_status',
                                 help="Hinterlegter Urlaubs- bzw. Abwesenheitsgrund für den selben Zeitraum.")
    reduce_overtime = fields.Boolean('Subtract from Overtime', compute='_compute_holiday_status')

    note = fields.Text(string='Note')
    is_locked = fields.Boolean(string='Locked')
    active = fields.Boolean(string='Active', default=True)
    is_leave_entry = fields.Boolean(string='Leave Entry', default=False)
    is_missed_attendance = fields.Boolean(string='Missed Attendance', default=False)
    check_in_date = fields.Date(string="Check In Date", compute='_compute_check_in_date', store=True)
    worked_hours = fields.Float(string='Worked Hours', compute='_compute_worked_hours', store=True, readonly=True,
                                help="Geleistete Arbeitszeit ohne Abzug gesetzlicher Pausen")
    leave_id = fields.Many2one('hr.leave')
    night_hours = fields.Float(string='Night Hours', compute='_compute_worked_hours',store=True,)
    holiday_hours = fields.Float(string='Holiday Hours', compute='_compute_worked_hours',store=True,)
    saturday_hours = fields.Float(string='Saturday Hours', compute='_compute_worked_hours',store=True,)
    sunday_hours = fields.Float(string='Sunday Hours', compute='_compute_worked_hours',store=True,)

    @api.depends('check_in', 'check_out','employee_id','employee_id.company_id.night_time_from',
                 'employee_id.resource_calendar_id','employee_id.resource_calendar_id.global_leave_ids','employee_id.resource_calendar_id.global_leave_ids.date_from','employee_id.resource_calendar_id.global_leave_ids.date_to')
    def _compute_worked_hours(self):
        for attendance in self:

            attendance.worked_hours = 0.0
            attendance.night_hours = 0.0
            attendance.holiday_hours = 0.0
            attendance.saturday_hours = 0.0
            attendance.sunday_hours = 0.0
            if attendance.check_out:
                delta = attendance.check_out - attendance.check_in
                attendance.worked_hours = delta.total_seconds() / 3600.0
                check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                    attendance.check_in)).date()
                leaves = self.env['hr.leave'].search([('employee_id', '=', attendance.employee_id.id),
                                                      ('request_date_from', '<=', check_in_date),
                                                      ('request_date_to', '>=', check_in_date),
                                                      ('state', '=', 'validate')])

                weekday = check_in_date.weekday()

                if weekday==5:
                    attendance.saturday_hours =attendance.worked_hours
                if weekday==6:
                    attendance.sunday_hours =attendance.worked_hours
                tz_check_in = fields.Datetime.context_timestamp(attendance, attendance.check_in)
                tz_check_in_time = tz_check_in.hour + ((tz_check_in.minute+(tz_check_in.second / 60)) / 60)
                tz_check_out = fields.Datetime.context_timestamp(attendance, attendance.check_out)
                tz_check_out_time = tz_check_out.hour + ((tz_check_out.minute+(tz_check_out.second / 60)) / 60)
                night_time_from = attendance.employee_id.company_id.night_time_from
                night_time_to = attendance.employee_id.company_id.night_time_to
                if night_time_to<night_time_from:
                    if night_time_from <= tz_check_in_time:
                        attendance.night_hours= tz_check_out_time-tz_check_in_time
                    elif night_time_to>=tz_check_in_time:
                        if night_time_to<tz_check_out_time:
                            attendance.night_hours = night_time_to - tz_check_in_time
                        else:
                            attendance.night_hours = tz_check_out_time - tz_check_in_time
                    elif night_time_from <= tz_check_out_time:
                        attendance.night_hours = tz_check_out_time - night_time_from
                else:
                    if night_time_from <= tz_check_in_time:
                        if night_time_to<tz_check_out_time:
                            attendance.night_hours = night_time_to - tz_check_in_time
                        else:
                            attendance.night_hours = tz_check_out_time - tz_check_in_time
                    elif night_time_from <= tz_check_out_time:
                        if night_time_to<tz_check_out_time:
                            attendance.night_hours = night_time_to - night_time_from
                        else:
                            attendance.night_hours = tz_check_out_time - night_time_from
                holidays_lines = attendance.employee_id.resource_calendar_id.global_leave_ids
                if holidays_lines:
                    hol_date = holidays_lines.filtered(
                        lambda r: r.date_from.date() <= check_in_date and r.date_to.date() >= check_in_date
                    )
                    if hol_date.ids:
                        attendance.holiday_hours = attendance.worked_hours


    def _cron_activate_leave_entry(self):
        attendances = self.env['hr.attendance'].search([
            ('is_leave_entry', '=', True),
            ('active', '!=', True),
            ('check_in_date', '<=', fields.Date.today()),
        ])
        attendances.write({'active': True})
        attendances.leave_id.write({'attendance_created': True})

    @api.depends('check_in')
    def _compute_check_in_date(self):
        for attendance in self:
            attendance.check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                attendance.check_in)).date()

    @api.depends('check_in', 'check_out', 'employee_id', 'employee_id.leave_ids', 'employee_id.leave_ids.state',
                 'employee_id.leave_ids.holiday_status_id.reduce_overtime')
    def _compute_holiday_status(self):
        for attendance in self:
            attendance.holiday_status = False
            attendance.reduce_overtime = False
            if attendance.employee_id:
                if attendance.check_in:
                    check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                        attendance.check_in)).date()
                    if attendance.is_leave_entry and attendance.leave_id:
                        attendance.holiday_status = attendance.leave_id.holiday_status_id.name
                        if attendance.leave_id.holiday_status_id.reduce_overtime:
                            attendance.reduce_overtime = True
                    holidays_lines = attendance.employee_id.resource_calendar_id.global_leave_ids
                    if holidays_lines:
                        hol_date = holidays_lines.filtered(
                            lambda r: r.date_from.date() <= check_in_date and r.date_to.date() >= check_in_date
                        )
                        if hol_date.ids:
                            attendance.holiday_status = "Gesetzlicher Feiertag"

    @api.depends('is_locked', 'check_in', 'check_out', 'add_expect_time', 'employee_id', 'employee_id.attendance_ids',
                 'employee_id.attendance_ids.check_in', 'employee_id.attendance_ids.check_out',
                 'employee_id.attendance_ids.add_expect_time', 'employee_id.resource_calendar_id.legal_break_ids',
                 'employee_id.resource_calendar_id.global_leave_ids',
                 'employee_id.resource_calendar_id.global_leave_ids.date_from',
                 'employee_id.resource_calendar_id.global_leave_ids.date_to',
                 'employee_id.resource_calendar_id.daily_break_included',
                 'employee_id.resource_calendar_id.legal_break_ids.work_time',
                 'employee_id.resource_calendar_id.legal_break_ids.legal_break', 'employee_id.company_id',
                 'employee_id.company_id.include_weekend_legal_break','employee_id.company_id.subtract_manual_break', 'worked_hours', 'holiday_status',
                 'employee_id.leave_ids', 'employee_id.over_time_history', 'employee_id.leave_ids.state',
                 'employee_id.leave_ids.holiday_status_id.reduce_overtime', 'employee_id.attendance_ids',
                 'employee_id.attendance_ids.check_in', 'employee_id.attendance_ids.check_out',
                 'employee_id.attendance_ids.worked_hours')
    def _compute_time(self):
        attendances = self.env['hr.attendance'].search([('id', 'in', self.ids), ('is_locked', '!=', True),
                                                        ], order='check_in asc')

        for attendance in attendances:
            attendance.expect_time = 0.00
            attendance.over_time_real = 0.00
            attendance.absences = 0.00
            attendance.legal_break = 0.00
            attendance.legal_worked_time = 0.00
            attendance.factor_time = 0.00
            attendance.over_time_record = 0.00
            is_legal_break = True

            break_time = 0.00

            if attendance.employee_id and attendance.check_out:
                resource_calendar_id = attendance.employee_id.resource_calendar_id
                if resource_calendar_id:
                    if attendance.check_in:
                        check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                            attendance.check_in)).date()
                        leaves = self.env['hr.leave'].search([('employee_id', '=', attendance.employee_id.id),
                                                              ('request_date_from', '<=', check_in_date),
                                                              ('request_date_to', '>=', check_in_date),
                                                              ('state', '=', 'validate')])

                        weekday = check_in_date.weekday()
                        previous_attendance = self.env['hr.attendance'].search([
                            ('employee_id', '=', attendance.employee_id.id),
                            ('check_in', '<', attendance.check_in),
                            ('id', '!=', attendance.id),
                        ], order='check_in desc', limit=1)
                        attendance_line = self.env['resource.calendar.attendance'].search(
                            [('dayofweek', '=', weekday), ('calendar_id', '=', resource_calendar_id.id)],
                            order='hour_to asc', )

                        legal_breaks = self.env['hr.legal.break'].search([
                            ('resource_calendar_id', '=', attendance.employee_id.resource_calendar_id.id)
                        ], order='work_time desc')
                        tz_check_in = fields.Datetime.context_timestamp(attendance, attendance.check_in)
                        tz_check_in_time = tz_check_in.hour + (tz_check_in.minute / 60)
                        tz_check_out = fields.Datetime.context_timestamp(attendance, attendance.check_out)
                        tz_check_out_time = tz_check_out.hour + (tz_check_out.minute / 60)
                        morning_time=0.0
                        afternoon_time=0.0
                        if attendance_line:
                            # if not attendance.holiday_status or (
                            #         leaves and leaves[0].holiday_status_id.unpaid or False) or (
                            #         leaves and leaves[0].holiday_status_id.reduce_overtime or False):
                            for att_line in attendance_line:
                                if not att_line.type == 'optional':
                                    attendance.expect_time += att_line.hour_to - att_line.hour_from
                                    if att_line.day_period=='morning':
                                        morning_time+= att_line.hour_to - att_line.hour_from
                                    elif att_line.day_period=='afternoon':
                                        afternoon_time+= att_line.hour_to - att_line.hour_from
                            if attendance.expect_time and resource_calendar_id.daily_break_included:
                                attendance.expect_time += resource_calendar_id.daily_break_included
                            if leaves:
                                for leave in leaves:
                                    if leave.holiday_status_id.reduce_overtime:

                                        if leave.request_unit_half:
                                            if leave.request_date_from_period=='am':
                                                attendance.expect_time = attendance.expect_time -resource_calendar_id.daily_break_included
                                            attendance.absences = 0.5
                                        else:
                                            attendance.expect_time -= resource_calendar_id.daily_break_included
                                            if not leave.number_of_days > 1:
                                                attendance.expect_time = leave.number_of_hours_display
                                            attendance.absences = 1.0
                                    elif leave.request_unit_half:
                                        if leave.request_date_from_period=='am':
                                            attendance.expect_time = attendance.expect_time - morning_time-resource_calendar_id.daily_break_included
                                        elif leave.request_date_from_period=='pm':
                                            attendance.expect_time = attendance.expect_time - afternoon_time
                                        attendance.absences = 0.5
                                    else:
                                        attendance.expect_time = attendance.expect_time - leave.number_of_hours_display - resource_calendar_id.daily_break_included
                                        attendance.expect_time = attendance.expect_time > 0 and attendance.expect_time or 0.0
                                        if leave.number_of_days > 1:
                                            attendance.expect_time = 0.0
                                        attendance.absences = 1.0
                            holidays_lines = resource_calendar_id.global_leave_ids
                            if holidays_lines:
                                hol_date = holidays_lines.filtered(
                                    lambda r: r.date_from.date() <= check_in_date and r.date_to.date() >= check_in_date
                                )
                                if hol_date.ids:
                                    attendance.expect_time = 0.0

                        else:
                            if attendance.employee_id.company_id:
                                if not attendance.employee_id.company_id.include_weekend_legal_break:
                                    is_legal_break = False
                        if previous_attendance:
                            previous_check_in_date = fields.Datetime.context_timestamp(self,
                                                                                       fields.Datetime.from_string(
                                                                                           previous_attendance.check_in)).date()
                            if not check_in_date != previous_check_in_date:
                                attendance.expect_time = 0.00
                                attendance.absences = 0.00

                        if is_legal_break and legal_breaks:
                            break_time = attendance._compute_break_time(legal_breaks)
                            attendance.legal_break = break_time

                        attendance.over_time_real = attendance.worked_hours - attendance.expect_time - break_time - attendance.add_expect_time
                        attendance.legal_worked_time = attendance.worked_hours - break_time
                        factor = 1.0
                        if attendance_line:
                            factor = attendance_line[0].factor
                            for att_line in attendance_line:
                                if att_line.hour_from <= tz_check_in_time:
                                    factor = att_line.factor
                        holidays_lines = attendance.employee_id.resource_calendar_id.global_leave_ids
                        if holidays_lines:
                            hol_date = holidays_lines.filtered(
                                lambda
                                    r: r.date_from.date() <= check_in_date and r.date_to.date() >= check_in_date
                            )
                            if hol_date.ids:
                                factor = resource_calendar_id.global_factor

                        attendance.factor_time = attendance.legal_worked_time * (factor - 1)
                        attendance.over_time_record = attendance.over_time_real + attendance.factor_time

    @api.depends('is_locked', 'check_in', 'check_out', 'add_expect_time', 'employee_id', 'employee_id.attendance_ids',
                 'employee_id.attendance_ids.check_in', 'employee_id.attendance_ids.check_out',
                 'employee_id.attendance_ids.add_expect_time', 'employee_id.resource_calendar_id.legal_break_ids',
                 'employee_id.resource_calendar_id.legal_break_ids.work_time',
                 'employee_id.resource_calendar_id.legal_break_ids.legal_break',
                 'employee_id.resource_calendar_id.daily_break_included',
                 'employee_id.company_id', 'employee_id.company_id.include_weekend_legal_break', 'employee_id.company_id.subtract_manual_break', 'worked_hours',
                 'holiday_status',
                 'employee_id.leave_ids', 'employee_id.over_time_history', 'employee_id.leave_ids.state',
                 'employee_id.leave_ids.holiday_status_id.reduce_overtime', 'employee_id.attendance_ids',
                 'employee_id.attendance_ids.check_in', 'employee_id.attendance_ids.check_out',
                 'employee_id.attendance_ids.worked_hours')
    def _compute_cumulative_time(self):
        attendances = self.env['hr.attendance'].search([('id', 'in', self.ids), ('is_locked', '!=', True),
                                                        ], order='check_in asc')

        for attendance in attendances:
            attendance.legal_worked_time_day = 0.00
            attendance.manual_break = 0.00

            is_legal_break = True

            manual_break = 0.00
            break_time = 0.00
            attendance.actual_time_daily_worked = 0.00
            attendance.over_time_history = attendance.employee_id.over_time_history or 0.0
            attendance.over_time_day = 0.00
            attendance.factor_time_day = 0.00
            attendance.over_time_record_day = 0.00

            if attendance.employee_id and attendance.check_out:
                resource_calendar_id = attendance.employee_id.resource_calendar_id
                if resource_calendar_id:
                    if attendance.check_in:
                        check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                            attendance.check_in)).date()

                        weekday = check_in_date.weekday()
                        previous_attendance = self.env['hr.attendance'].search([
                            ('employee_id', '=', attendance.employee_id.id),
                            ('check_in', '<', attendance.check_in),
                            ('id', '!=', attendance.id),
                        ], order='check_in desc', limit=1)
                        attendance_line = self.env['resource.calendar.attendance'].search(
                            [('dayofweek', '=', weekday), ('calendar_id', '=', resource_calendar_id.id)],
                            order='hour_to asc', )

                        legal_breaks = self.env['hr.legal.break'].search([
                            ('resource_calendar_id', '=', attendance.employee_id.resource_calendar_id.id)
                        ], order='work_time desc')
                        tz_check_in = fields.Datetime.context_timestamp(attendance, attendance.check_in)
                        tz_check_in_time = tz_check_in.hour + (tz_check_in.minute / 60)

                        if previous_attendance:
                            previous_check_in_date = fields.Datetime.context_timestamp(self,
                                                                                       fields.Datetime.from_string(
                                                                                           previous_attendance.check_in)).date()
                            if check_in_date != previous_check_in_date:
                                attendance.manual_break = 0.00
                                attendance.actual_time_daily_worked = attendance.worked_hours
                                attendance.legal_worked_time_day = attendance.actual_time_daily_worked
                                if is_legal_break and legal_breaks:
                                    break_time = attendance._compute_break_time(legal_breaks)

                                    attendance.legal_worked_time_day = attendance.actual_time_daily_worked - break_time

                                attendance.over_time_day = attendance.over_time_real
                                attendance.factor_time_day = attendance.factor_time

                            else:
                                attendance.actual_time_daily_worked = previous_attendance.actual_time_daily_worked + attendance.worked_hours
                                attendance.legal_worked_time_day = attendance.actual_time_daily_worked
                                if previous_attendance.check_out and attendance.check_in:
                                    manual_break = attendance.check_in - previous_attendance.check_out
                                    manual_break = manual_break.total_seconds() / 3600.0
                                attendance.manual_break = manual_break + previous_attendance.manual_break

                                if is_legal_break and legal_breaks:
                                    break_time = attendance._compute_break_time(legal_breaks)
                                    attendance.legal_worked_time_day = previous_attendance.legal_worked_time_day + attendance.worked_hours - break_time

                                attendance.over_time_day = previous_attendance.over_time_day + attendance.over_time_real
                                attendance.factor_time_day = previous_attendance.factor_time_day +attendance.factor_time

                            attendance.over_time_history = previous_attendance.over_time_history + attendance.over_time_real
                        else:

                            attendance.actual_time_daily_worked = attendance.worked_hours
                            attendance.legal_worked_time_day = attendance.actual_time_daily_worked
                            attendance.manual_break = 0.00
                            if is_legal_break and legal_breaks:
                                break_time = attendance._compute_break_time(legal_breaks)
                                attendance.legal_worked_time_day = attendance.actual_time_daily_worked - break_time

                            attendance.over_time_day = attendance.over_time_real
                            attendance.factor_time_day = attendance.factor_time
                            attendance.over_time_history += attendance.over_time_real

                        attendance.over_time_record_day = attendance.over_time_day + attendance.factor_time_day
                        attendance.over_time_history += attendance.factor_time

    def _compute_break_time(self, legal_breaks):
        self.ensure_one()
        attendances_in_day = self.env['hr.attendance'].search([
            ('employee_id', '=', self.employee_id.id),
            ('check_in_date', '=', self.check_in_date),
            ('check_out', '!=', False),
            ('is_leave_entry', '!=', True),
        ], order='check_in desc')
        if attendances_in_day:
            total_worked_time = sum(attendances_in_day.mapped('worked_hours'))
            first_check_in = min(attendances_in_day.mapped('check_in'))
            last_check_out = max(attendances_in_day.mapped('check_out'))
            delta = last_check_out - first_check_in
            total_hours = delta.total_seconds() / 3600.0
            manual_breaks=0.0
            if self.employee_id.company_id.subtract_manual_break:
                manual_breaks = total_hours - total_worked_time
            next_attendance_in_day = self.env['hr.attendance'].search([
                ('employee_id', '=', self.employee_id.id),
                ('check_in', '>', self.check_in),
                ('check_in_date', '=', self.check_in_date),
                ('id', '!=', self.id),
            ], order='check_in desc', limit=1)

            for legal_break in legal_breaks:
                if legal_break.work_time <= total_worked_time:
                    break_time = legal_break.legal_break - manual_breaks
                    break_time = break_time > 0.00 and break_time or 0.00
                    if self._check_worktime_factor_count():
                        break_time = break_time * (self.worked_hours / total_worked_time)
                    elif next_attendance_in_day:
                        break_time = 0.0
                    return break_time

        return 0.0

    def _check_worktime_factor_count(self):
        self.ensure_one()
        resource_calendar_id = self.employee_id.resource_calendar_id
        if resource_calendar_id:
            if self.check_in:
                check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                    self.check_in)).date()

                weekday = check_in_date.weekday()
                attendance_lines = self.env['resource.calendar.attendance'].search(
                    [('dayofweek', '=', weekday), ('calendar_id', '=', resource_calendar_id.id)])
                factor_count = [x.factor for x in attendance_lines]
                if len(set(factor_count)) > 1:
                    return True
        return False

    @api.model
    def create(self, vals):
        if vals.get('check_in', False):
            check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                vals.get('check_in', False))).date()

            previous_attendances = self.env['hr.attendance'].search([
                ('employee_id', '=', vals.get('employee_id', False)),
                ('check_in_date', '<', check_in_date),
                ('is_locked', '!=', True),
            ], order='check_in desc')
            previous_attendances.write({'is_locked': True})
            later_attendances = self.env['hr.attendance'].search([
                ('employee_id', '=', vals.get('employee_id', False)),
                ('check_in_date', '>=', check_in_date),
                ('is_locked', '=', True),
            ], order='check_in desc')
            later_attendances.write({'is_locked': False})
            if vals.get('check_out', False):

                check_in = datetime.strptime(vals.get('check_in'), DEFAULT_SERVER_DATETIME_FORMAT)
                tz_check_in = fields.Datetime.context_timestamp(self, check_in)

                check_out = datetime.strptime(vals.get('check_out'), DEFAULT_SERVER_DATETIME_FORMAT)
                tz_check_out = fields.Datetime.context_timestamp(self, check_out)
                new_entry = False
                res = super(HrAttendance, self).create(vals)
                if tz_check_in.date() != tz_check_out.date():
                    new_entry = True
                elif res._check_worktime_factor_count():
                    new_entry = True
                if new_entry:
                    res.write(vals)
                return res
        return super(HrAttendance, self).create(vals)

    def write(self, vals):
        if vals.get('check_in', False) or vals.get('check_out', False):
            for record in self:
                check_out = vals.get('check_out', False) or record.check_out
                if check_out:
                    check_in = vals.get('check_in', False) or record.check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                    check_out = vals.get('check_out', False) or record.check_out.strftime(
                        DEFAULT_SERVER_DATETIME_FORMAT)
                    employee_id = vals.get('employee_id', False) or record.employee_id.id

                    check_in = datetime.strptime(check_in, DEFAULT_SERVER_DATETIME_FORMAT)
                    tz_check_in = fields.Datetime.context_timestamp(record, check_in)
                    check_out = datetime.strptime(str(check_out), DEFAULT_SERVER_DATETIME_FORMAT)
                    tz_check_out = fields.Datetime.context_timestamp(record, check_out)

                    if tz_check_in.date() != tz_check_out.date():

                        new_tz_check_in = fields.Datetime.context_timestamp(record, datetime.combine(tz_check_in.date(),
                                                                                                     time(23, 59, 59)))
                        tz_diff = datetime.strptime(fields.Datetime.to_string(new_tz_check_in),
                                                    DEFAULT_SERVER_DATETIME_FORMAT) - datetime.combine(
                            tz_check_in.date(), time(23, 59, 59))

                        new_check_out = datetime.combine(tz_check_in.date(), time(23, 59, 59)) - tz_diff

                        vals = {
                            'check_in': check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'check_out': new_check_out.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'employee_id': employee_id,
                        }
                        record.write(vals)
                        new_check_in = new_check_out + timedelta(seconds=1)

                        new_vals = {
                            'check_in': new_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'check_out': check_out.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'employee_id': employee_id,
                        }
                        new_record = self.create(new_vals)
                    elif record._check_worktime_factor_count():
                        resource_calendar_id = self.employee_id.resource_calendar_id
                        if resource_calendar_id:
                            tz_check_in_time = tz_check_in.hour + (tz_check_in.minute / 60)
                            tz_check_out_time = tz_check_out.hour + (tz_check_out.minute / 60)
                            tz_diff = datetime.strptime(fields.Datetime.to_string(tz_check_in),
                                                        DEFAULT_SERVER_DATETIME_FORMAT) - datetime.strptime(
                                fields.Datetime.to_string(check_in), DEFAULT_SERVER_DATETIME_FORMAT)
                            if check_in and check_out:
                                check_in_date = fields.Datetime.context_timestamp(record, fields.Datetime.from_string(
                                    check_in)).date()

                                weekday = check_in_date.weekday()
                                attendance_lines = self.env['resource.calendar.attendance'].search(
                                    [('dayofweek', '=', weekday), ('calendar_id', '=', resource_calendar_id.id),
                                     ('hour_to', '>', tz_check_in_time), ('hour_from', '<', tz_check_out_time)],
                                    order='hour_from desc')
                                if attendance_lines and len(attendance_lines) > 1:
                                    factor = attendance_lines[0].factor
                                    new_hour = int(attendance_lines[0].hour_from)
                                    new_minute = round(math.modf(attendance_lines[0].hour_from)[0] * 60.0)
                                    for attendance_line in attendance_lines:
                                        if factor != attendance_line.factor:
                                            new_check_out = datetime.combine(tz_check_in.date(),
                                                                             time(new_hour, new_minute, 00)) - tz_diff
                                            new_check_in = new_check_out
                                            vals = {
                                                'check_in': new_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                                                'check_out': check_out.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                                                'employee_id': employee_id,
                                            }
                                            record.write(vals)

                                            new_vals = {
                                                'check_in': check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                                                'check_out': new_check_out.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                                                'employee_id': employee_id,
                                            }
                                            new_record = self.create(new_vals)
                                            break
                                        new_hour = int(attendance_line.hour_from)
                                        new_minute = round(math.modf(attendance_line.hour_from)[0] * 60.0)

        res= super(HrAttendance, self).write(vals)
        if 'is_locked' in vals.keys() :
            for record in self:
                check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                    record.check_in)).date()
                if vals.get('is_locked',False):
                    previous_attendances = self.env['hr.attendance'].search([
                        ('employee_id', '=', record.employee_id.id),
                        ('check_in_date', '<', check_in_date),
                        ('is_locked', '!=', True),
                    ], order='check_in desc')
                    previous_attendances.write({'is_locked': True})
                else:
                    later_attendances = self.env['hr.attendance'].search([
                        ('employee_id', '=', record.employee_id.id),
                        ('check_in_date', '>=', check_in_date),
                        ('is_locked', '=', True),
                    ], order='check_in desc')
                    later_attendances.write({'is_locked': False})
        return res
