# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from random import choice
from string import digits

from odoo import models, fields, api, exceptions, _, SUPERUSER_ID


class HrEmployeeBase(models.AbstractModel):
    _inherit = "hr.employee.base"
    _description = "Employee"


    leave_ids = fields.One2many('hr.leave', 'employee_id', help='list of leaves for the employee')
    over_time_history = fields.Float('Overtime (History)',default=0.00)
