# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    include_weekend_legal_break = fields.Boolean(string="Include Legal Break in Weekends", readonly=False)
    subtract_manual_break = fields.Boolean(string="Subtract Manual Break from Legal Break", readonly=False,default=True)
    night_time_from = fields.Float( string="Night Time From", readonly=False)
    night_time_to = fields.Float( string="Night Time To", readonly=False)
