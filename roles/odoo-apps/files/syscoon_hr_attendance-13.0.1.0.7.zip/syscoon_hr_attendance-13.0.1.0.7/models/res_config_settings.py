# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    include_weekend_legal_break = fields.Boolean(related='company_id.include_weekend_legal_break', string="Include Legal Break in Weekends", readonly=False)
    subtract_manual_break = fields.Boolean(related='company_id.subtract_manual_break', string="Subtract Manual Break from Legal Break", readonly=False)
    night_time_from = fields.Float(related='company_id.night_time_from', string="Night Time From", readonly=False)
    night_time_to = fields.Float(related='company_id.night_time_to', string="Night Time To", readonly=False)
