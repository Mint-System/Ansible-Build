# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, exceptions, _
from datetime import datetime, time, timedelta, date
from dateutil.relativedelta import relativedelta
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from pytz import timezone, UTC
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
import math


class HrMissedAttendance(models.Model):
    _name = "hr.missed.attendance"
    _description = "Missed Attendances"

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    department_id = fields.Many2one('hr.department', string="Department", related="employee_id.department_id",
                                    readonly=True)
    date = fields.Date(string="Date",  required=True)

    def _cron_generate_entry(self):
        today=fields.Date.today()
        MissedAttendance = self.env['hr.missed.attendance']
        weekday = today.weekday()
        employees = self.env['hr.employee'].search([])
        for employee in employees:
            holiday_status =False
            missed_attendance = MissedAttendance.search([
                ('employee_id', '=', employee.id),
                ('date', '=', today),
            ])
            if not missed_attendance:
                resource_calendar_id = employee.resource_calendar_id
                work_time_lines = self.env['resource.calendar.attendance'].search(
                    [('dayofweek', '=', weekday),('type', '=', 'mandatory'), ('calendar_id', '=', resource_calendar_id.id)
                    ])
                if work_time_lines:
                    attendance = self.env['hr.attendance'].search([
                        ('employee_id', '=', employee.id),
                        ('check_in_date', '=', today),
                    ],  limit=1)
                    holidays_lines = resource_calendar_id.global_leave_ids
                    if holidays_lines:
                        hol_date = holidays_lines.filtered(
                            lambda r: r.date_from.date() <= today and r.date_to.date() >= today
                        )
                        if hol_date.ids:
                            holiday_status = True

                    if not attendance and not holiday_status:
                        MissedAttendance.create({
                            'employee_id':employee.id,
                            'date':today })
                        check_in_date = today
                        tz_check_in = fields.Datetime.context_timestamp(self, datetime.combine(check_in_date,
                                                                                                time(00, 00, 00)))
                        tz_diff = datetime.strptime(fields.Datetime.to_string(tz_check_in),
                                                    DEFAULT_SERVER_DATETIME_FORMAT) - datetime.combine(check_in_date,
                                                                                                       time(00, 00, 00))

                        new_tz_check_in = datetime.combine(check_in_date, time(00, 00, 00)) - tz_diff
                        vals = {
                            'check_in': new_tz_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'check_out': new_tz_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                            'employee_id': employee.id,
                            'is_missed_attendance': True,

                        }
                        self.env['hr.attendance'].create(vals)

class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    @api.model
    def create(self, vals):
        if not vals.get('is_missed_attendance', False):
            if vals.get('check_in', False):
                check_in_date = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(
                    vals.get('check_in', False))).date()
                missed_attendance = self.env['hr.missed.attendance'].search([
                        ('employee_id', '=', vals.get('employee_id', False)),
                        ('date', '=', check_in_date),
                    ])
                if missed_attendance:
                    missed_attendance.unlink()
                missed_attendance_entry = self.env['hr.attendance'].search([
                        ('employee_id', '=', vals.get('employee_id', False)),
                        ('check_in_date', '=', check_in_date),
                        ('is_missed_attendance', '=', True),
                    ])
                if missed_attendance_entry:
                    missed_attendance_entry.unlink()
        return super(HrAttendance, self).create(vals)
