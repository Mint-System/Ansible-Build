# -*- coding: utf-8 -*-
from . import hr_attendance
from . import hr_employee
from . import hr_missed_attendance
from . import res_company
from . import res_config_settings
from . import hr_leave
from . import resource

