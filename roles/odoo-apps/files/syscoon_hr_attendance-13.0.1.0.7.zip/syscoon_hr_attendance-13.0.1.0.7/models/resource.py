# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields,api, _
from odoo.exceptions import ValidationError

from collections import defaultdict
from pytz import utc
from odoo.tools.float_utils import float_round
from odoo.osv import expression

class ResourceCalendarAttendance(models.Model):
    _inherit = 'resource.calendar.attendance'

    factor = fields.Float( 'Factor', default=1.0)
    type = fields.Selection([('optional', 'Optional'), ('mandatory', 'Mandatory')], 'Type', default='mandatory')

    @api.constrains('factor')
    def _check_factor(self):
        for record in self:
            if record.factor<1.0:
                raise ValidationError(_("The value of Factor must be greater than or equal to 1.0"))
class ResourceCalendar(models.Model):
    _inherit = 'resource.calendar'
    def _get_default_legal_break_ids(self):
        return [(0,0,{'work_time':6.0,'legal_break':(30 / 60 )}),(0,0,{'work_time':9.0,'legal_break':(45 / 60 )})]


    global_factor = fields.Float( 'Global Factor', default=1.0)
    daily_break_included = fields.Float( 'Daily Break Included', default=0.0)
    legal_break_ids = fields.One2many('hr.legal.break', 'resource_calendar_id', default=_get_default_legal_break_ids)

    # --------------------------------------------------
    # Computation API
    # --------------------------------------------------
    def _attendance_intervals_batch(self, start_dt, end_dt, resources=None, domain=None, tz=None):

        domain = domain if domain is not None else []
        domain = expression.AND([domain, [
            ('type', '=', 'mandatory'),
        ]])

        rec = super(ResourceCalendar, self)._attendance_intervals_batch(start_dt, end_dt, resources=resources, domain=domain,
                                                                  tz=tz)
        return rec

    def _compute_hours_per_day(self, attendances):
        if not attendances:
            return 0

        hour_count = 0.0
        for attendance in attendances:
            if attendance.type=='mandatory':
                hour_count += attendance.hour_to - attendance.hour_from

        if self.two_weeks_calendar:
            number_of_days = len(set(attendances.filtered(lambda cal: cal.week_type == '1' and cal.type=='mandatory').mapped('dayofweek')))
            number_of_days += len(set(attendances.filtered(lambda cal: cal.week_type == '0' and cal.type=='mandatory').mapped('dayofweek')))
        else:
            number_of_days = len(set(attendances.filtered(lambda cal: cal.type=='mandatory').mapped('dayofweek')))

        return number_of_days and float_round(hour_count / float(number_of_days), precision_digits=2) or 0.0

    @api.onchange('attendance_ids', 'two_weeks_calendar')
    def _onchange_hours_per_day(self):
        super(ResourceCalendar, self)._onchange_hours_per_day()
        attendances = self._get_global_attendances()
        self.hours_per_day = self._compute_hours_per_day(attendances)


    @api.constrains('global_factor')
    def _check_factor(self):
        for record in self:
            if record.global_factor < 1.0:
                raise ValidationError(_("The value of Factor must be greater than or equal to 1.0"))

    @api.model
    def default_get(self, fields):
        result = super(ResourceCalendar, self).default_get(fields)
        if not result.get('legal_break_ids') and fields:
           result['legal_break_ids'] = [(0,0,{'work_time':6.0,'legal_break':(30 / 60 )}),(0,0,{'work_time':9.0,'legal_break':(45 / 60 )})]
        return result


class HrLegalBreak(models.Model):
    _name = "hr.legal.break"
    _order = "work_time"
    _description = "Legal Break"

    resource_calendar_id = fields.Many2one('resource.calendar', "Work Time")
    work_time = fields.Float("Work Hours >=")
    legal_break = fields.Float("Legal Break")
