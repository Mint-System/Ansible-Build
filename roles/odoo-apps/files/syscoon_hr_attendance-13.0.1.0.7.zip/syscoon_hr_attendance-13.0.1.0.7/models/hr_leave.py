
from odoo import api, fields, models, _
from datetime import datetime,time,timedelta,date
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import AccessError, UserError, ValidationError
class HolidaysRequest(models.Model):

    _inherit = "hr.leave"
    attendance_created = fields.Boolean('Attendance Created', default=False)

    def action_approve(self):
        res= super(HolidaysRequest, self).action_approve()
        for leave in self:
            check_in_date = leave.request_date_from
            while check_in_date<=leave.request_date_to:
                attendance_line = self.env['hr.attendance'].search(
                    [('check_in_date', '=', check_in_date), ('employee_id', '=', leave.employee_id.id)])
                calendar_line = self.env['resource.calendar.attendance'].search(
                    [('dayofweek', '=', check_in_date.weekday()), ('calendar_id', '=', leave.employee_id.resource_calendar_id.id)])
                if calendar_line:
                    hours, minutes = divmod(calendar_line[0].hour_from*60, 60)

                    tz_check_in = fields.Datetime.context_timestamp(leave, datetime.combine(check_in_date,time(int(hours), int(minutes), 00)))
                    tz_diff = datetime.strptime(fields.Datetime.to_string(tz_check_in),DEFAULT_SERVER_DATETIME_FORMAT) - datetime.combine(check_in_date,time(int(hours), int(minutes), 00))

                    new_tz_check_in = datetime.combine(check_in_date, time(00, 00, 00)) - tz_diff
                    active=False

                    if check_in_date<=fields.Date.today():
                        active = True
                    vals = {
                        'check_in': new_tz_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                        'check_out': new_tz_check_in.strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                        'employee_id': leave.employee_id.id,
                        'active': active,
                        'is_leave_entry': True,
                        'leave_id': leave.id,

                    }
                    self.env['hr.attendance'].create(vals)
                check_in_date = check_in_date + timedelta(days=1)
            attendances = self.env['hr.attendance'].search([
                ('employee_id', '=', leave.employee_id.id),
                ('check_in_date', '>=', leave.request_date_from),
                ('is_locked', '=', True),
            ], order='check_in desc')
            attendances.write({'is_locked': False})
        return res

    def action_refuse(self):
        res = super(HolidaysRequest, self).action_refuse()
        for leave in self:
            attendance_line = self.env['hr.attendance'].search([('leave_id', '=', leave.id)])
            attendance_line.unlink()

        return res

class HolidaysType(models.Model):
    _inherit = "hr.leave.type"
    reduce_overtime = fields.Boolean('Subtract from Overtime', default=False)
