* Petar Najman <petar.najman@modoolar.com>
* Mladen Meseldzija <mladen.meseldzija@modoolar.com>
* Alexey Pelykh <alexey.pelykh@brainbeanapps.com>
* Manuel Calero - Tecnativa
