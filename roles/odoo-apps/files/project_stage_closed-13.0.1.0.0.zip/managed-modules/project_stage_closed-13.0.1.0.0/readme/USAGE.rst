To use this module, you need to:

#. Have Manager rights for Project group.
#. Go to *Project > Configuration > Stages*.
#. You have the "Closed" flag available to be checked on the form view.
