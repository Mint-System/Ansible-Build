This module provides a 'closed' flag on project task stages.
