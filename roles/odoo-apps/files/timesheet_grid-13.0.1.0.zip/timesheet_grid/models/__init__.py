# -*- coding: utf-8 -*-

from . import analytic
from . import hr_employee
from . import res_config_settings
from . import res_company
from . import res_users
