from odoo import api, models, _
import logging
_logger = logging.getLogger(__name__)

class DocumentReport(models.AbstractModel):
    _name = 'report.gio_payroll_custom.hr_payroll_report_view'
    _description = 'Lohnabrechnung'

    def _get_report_values(self, docids, data=None):

        # get the report action back as we will need its data
        report = self.env['ir.actions.report']._get_report_from_name('gio_payroll_custom.hr_payroll_report_view')

        # get the records selected for this rendering of the report
        docs = self.env[report.model].browse(docids)

        # return a custom rendering context
        return {
            'docs': docs,
        }   