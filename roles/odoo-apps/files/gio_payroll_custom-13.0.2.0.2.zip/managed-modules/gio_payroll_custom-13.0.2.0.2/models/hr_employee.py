# -*- coding: utf-8 -*-
# Copyright: giordano.ch AG
# Autor: Benjamin Taccone
# Version: 1.0 - 02.03.2018

from odoo import api, fields, models, _


class Employee(models.Model):
    _inherit = 'hr.employee'

    gio_children_training = fields.Integer(string="Anzahl Kinder im Studium")

class EmployeePublic(models.Model):
    _inherit = 'hr.employee.public'

    gio_children_training = fields.Integer(string="Anzahl Kinder im Studium")
