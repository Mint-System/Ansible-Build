# -*- coding: utf-8 -*-
# Copyright: giordano.ch AG


from odoo import api, fields, models, _


class HrPayrollWork(models.Model):
    _name = 'hr.payroll.work'
    _description = 'shares employer'
    _rec_name = 'gio_name'

    gio_name = fields.Char(string='Name')
    gio_wage_limit = fields.Float(string='Monatslohngrenze')
    gio_ahv = fields.Float(string='AHV / IV / EO', digits='Payroll Rate')
    gio_alv = fields.Float(
        string='ALV', digits='Payroll Rate')
    gio_alv2 = fields.Float(
        string='ALV 2', digits='Payroll Rate')
    gio_nbu = fields.Float(
        string='NBU', digits='Payroll Rate')
    gio_ktgf = fields.Float(string='KTG Frauen',
                            digits='Payroll Rate')
    gio_ktgm = fields.Float(string='KTG Männer',
                            digits='Payroll Rate')
    gio_uvg_supplementary_insurance = fields.Float(
        string='UVG Ergänzungsversicherung', digits='Payroll Rate')
    gio_uvg_supplementary_insurance2 = fields.Float(
        string='UVG Ergänzungsversicherung 2', digits='Payroll Rate')
    gio_uvg_supplementary_insurance_ag = fields.Float(
        string='UVG Ergänzungsversicherung AG', digits='Payroll Rate')
    gio_uvg_supplementary_insurance_ag2 = fields.Float(
        string='UVG Ergänzungsversicherung 2 AG', digits='Payroll Rate')
    gio_ahv_ag = fields.Float(
        string='AHV / IV / EO AG', digits='Payroll Rate')
    gio_alv_ag = fields.Float(
        string='ALV AG', digits='Payroll Rate')
    gio_alv2_ag = fields.Float(
        string='ALV 2 AG', digits='Payroll Rate')
    gio_bu = fields.Float(string='BU', digits='Payroll Rate')
    gio_ktgf_ag = fields.Float(
        string='KTG Frauen AG', digits='Payroll Rate')
    gio_ktgm_ag = fields.Float(
        string='KTG Männer AG', digits='Payroll Rate')
    gio_fak = fields.Float(string='Familienausgleichskasse (FAK)',
                           digits='Payroll Rate')
    gio_vwk = fields.Float(string='Verwaltungskosten',
                           digits='Payroll Rate')
    gio_child_allowances = fields.Float(
        string='Kinderzulagen', digits='Payroll Rate')
    gio_training_allowances = fields.Float(
        string='Ausbildungszulagen', digits='Payroll Rate')
