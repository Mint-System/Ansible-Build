# -*- coding: utf-8 -*-
# Copyright: giordano.ch AG

from . import hr_payroll_work
from . import hr_contract
from . import hr_employee
from . import hr_payslip
from . import hr_salary_rule