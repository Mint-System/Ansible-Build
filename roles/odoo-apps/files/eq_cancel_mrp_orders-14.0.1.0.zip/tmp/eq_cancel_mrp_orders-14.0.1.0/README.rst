        
==========================
Cancel Manufacturing Order
==========================

.. image:: ./static/description/icon.png
  :width: 100
  :alt: Icon

This Module allows user to cancel done manufacturing orders and reset to draft manufacturing orders.
* Allows you to cancel Done manufacturing order.
* Allows you to Reset to Draft cancel manufacturing order.
* Cancel done stock move and reverse the inventory in system.
* Cancel finished work orders.
* Cancel scrap orders.

Usage
~~~~~

Clone module into Odoo addon directory.

.. code-block:: bash

    git clone git@gitlab.com:mint-system/odoo-app-cancel-manufacturing-order.git ./addons/eq_cancel_mrp_orders