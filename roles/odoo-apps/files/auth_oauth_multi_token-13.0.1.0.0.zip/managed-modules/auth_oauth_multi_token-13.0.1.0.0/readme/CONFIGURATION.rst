On users' form you can set the number of maximum simultaneous connections.

By default 10 connections are allowed.

From there you can also clear / inactivate existing tokens.
