This module depends on modules found in these repositories:

* `OCA/timesheet <https://github.com/OCA/timesheet>`__
* `OCA/web <https://github.com/OCA/web>`__
