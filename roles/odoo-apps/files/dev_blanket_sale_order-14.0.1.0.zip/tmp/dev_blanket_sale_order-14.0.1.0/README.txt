Blanket Sale Order:
=========================================================

Go to Setting / apps and search "Blanket / Blanket Sale Order" and Install

And, you are done with installation. Congratulations!