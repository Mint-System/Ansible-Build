To use this module, you need to:

* Install it.
* Send an email.
* Nobody will know it comes from Odoo.
