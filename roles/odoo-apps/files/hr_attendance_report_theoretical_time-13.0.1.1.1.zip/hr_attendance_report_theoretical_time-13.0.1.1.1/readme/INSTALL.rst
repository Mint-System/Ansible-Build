On installation time, this module computes the theoretical hours for the day of
the attendance check-in, so if you have a lot of records, this would be a bit
slow.
