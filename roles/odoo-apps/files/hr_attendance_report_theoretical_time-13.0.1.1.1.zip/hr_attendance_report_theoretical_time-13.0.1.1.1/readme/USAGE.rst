#. Go to *Attendances > Reporting > Theoretical vs Attended Time Analysis*.
#. Check pivot table or look at the graph view.
