**Images**

* Font Awesome: `Icon <http://fontawesome.io>`_.
