# Odoo App: HR Payroll Share

<img width="150" src="./static/description/icon.png" />

CH localization for Odoo payroll.

## Usage

Clone into Odoo addon directory.

```bash
git clone git@gitlab.com:mint-system/odoo-app-hr-payroll-share.git ./addons/gio_payroll_custom
```
