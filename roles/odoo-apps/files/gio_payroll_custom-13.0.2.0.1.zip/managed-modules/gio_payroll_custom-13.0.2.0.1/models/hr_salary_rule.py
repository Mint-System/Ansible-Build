# -*- coding: utf-8 -*-
# Copyright: giordano.ch AG

from odoo import api, fields, models, _
from odoo.tools.safe_eval import safe_eval
from odoo.exceptions import UserError, ValidationError


class HrSalaryRule(models.Model):
    _inherit = 'hr.salary.rule'

    gio_amount_python_compute = fields.Text(
        string='Basic Python Code', default='result=0')

    def _compute_basic_rule(self, localdict):
        self.ensure_one()
        try:
            safe_eval(self.gio_amount_python_compute or 0.0,
                      localdict, mode='exec', nocopy=True)
            return float(localdict['result'])
        except Exception as e:
            raise UserError(_('Wrong python code defined for salary rule %s (%s).\nError: %s') % (
                self.name, self.code, e))
