This module adjusts the domain applied to task field in order to limit task
selection to currently-selected project. If `project_stage_closed` module is
installed, also limits selection to tasks in any of "Open" stages in order to
accommodate a project flow.
