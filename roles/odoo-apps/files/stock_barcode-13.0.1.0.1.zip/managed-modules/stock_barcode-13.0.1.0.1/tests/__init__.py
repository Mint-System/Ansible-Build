# -*- coding: utf-8 -*-

from . import test_barcode_client_action
