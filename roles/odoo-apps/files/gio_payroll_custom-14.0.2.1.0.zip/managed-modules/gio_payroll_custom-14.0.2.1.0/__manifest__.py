# -*- coding: utf-8 -*-
{
    'name': "HR Payroll Share",

    'summary': """
        CH localization for Odoo payroll.
    """,

    'description': """
        CH localization for Odoo payroll.
    """,

    'author': 'giordano.ch AG',
    'website': 'https://www.giordano.ch',
    'license': 'OPL-1',
    'version': '14.0.2.1.0',
    'category': 'HR',

    'depends': [
        'base',
        'hr',
        'hr_payroll',
    ],

    'data': [
        'security/ir.model.access.csv',
        'data/gio_decimal_data.xml',
        'data/hr_payroll_data.xml',
        'data/hr_salary_rule_category.xml',
        'data/hr_salary_rule.xml',
        'views/gio_hr_payroll_work_view.xml',
        'views/gio_hr_contract_view.xml',
        'views/gio_hr_employee_view.xml',
        'views/gio_hr_payslip_view.xml',
        'views/gio_hr_salary_rule_view.xml',
        'report/hr_payroll_report.xml'
    ],
}
