# -*- coding: utf-8 -*-
# Copyright: giordano.ch AG
# Autor: Benjamin Taccone
# Version: 1.0 - 02.03.2018

from odoo import api, fields, models, _


class Employee(models.Model):
    _inherit = 'hr.contract'

    gio_enforcement_office = fields.Float(string="Betreibungsamt")
    gio_representation_charges = fields.Float(string="Repräsentationsspesen")
    gio_bonus = fields.Float(string="Bonus")
    gio_name = fields.Many2one(
        'hr.payroll.work', string="Anteile AN / AG", store=True)
    gio_private_share_vehicle = fields.Float(
        string="Privatanteil Geschäftsfahrzeug")
    gio_advance = fields.Float(string="Vorschuss")
    gio_travel_charges = fields.Float(string="Reisespesen")
    gio_crossborder = fields.Float(string="Grenzgängersteuer")
    gio_ml_dreizehn = fields.Float(string="Anteil 13. Monatslohn")
    gio_holiday_rate = fields.Float(string="Ferienentschädigung")
    gio_holiday_surcharge = fields.Float(string="Feiertagszuschlag")
    gio_bvg_amount = fields.Float(string="BVG Betrag")
    gio_bvg_rate = fields.Float(string="BVG Prozentsatz")
    gio_sourcetax = fields.Float(string="Quellensteuer")
    gio_wage_monthly = fields.Float(string="Monatslohn")
    gio_wage_hourly = fields.Float(string="Stundenlohn")
    gio_wage_type = fields.Selection(
        [('monthly', 'Monatslohn'), ('hourly', 'Stundenlohn')])
