# Blanket Sale Order

Go to Setting / apps and search "Blanket / Blanket Sale Order" and Install.

## Changelog

10 October 2020  
v 14.0.1.0

* Module Created

## Contributors

DevintelleCS Odoo Expert Team

Get in Touch for other odoo Devlopment & Support:  
Skype: devintelle  
What's app : +91 8780543446  
Mail: devintelle@gmail.com  