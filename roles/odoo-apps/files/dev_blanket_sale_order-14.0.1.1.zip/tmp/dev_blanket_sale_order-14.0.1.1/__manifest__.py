# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

{
    'name': 'Blanket Sale Order',
    'version': '14.0.1.1',
    'sequence': 1,
    'category': 'Sales',
    'description':"""
       Odoo app allow Blanket Sale Order aggreement between Seller and Customer.
    """,
    'summary': 'Odoo app allow Blanket Sale Order aggreement between Seller and Customer.',
    'depends': ['sale_management'],
    'data': [
        'security/ir.model.access.csv',
        'data/blanket_sequence_view.xml',
        'views/blanket_order_view.xml',
        'views/sale_view.xml',
        'wizard/create_sale_quotation_view.xml',
        'data/cron_blanket_expiry_view.xml'
    ],
    'demo': [],
    'test': [],
    'css': [],
    'qweb': [],
    'js': [],
    'images': ['images/main_screenshot.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
    
    # author and support Details =============#
    'author': 'DevIntelle Consulting Service Pvt.Ltd',
    'website': 'http://www.devintellecs.com',    
    'maintainer': 'DevIntelle Consulting Service Pvt.Ltd', 
    'support': 'devintelle@gmail.com',
    'price':25.0,
    'currency':'EUR',
    'live_test_url':'https://youtu.be/GOlRnho-tzI',
}
