===================
MRP Documents Share
===================

.. image:: ./static/description/icon.png
  :width: 100
  :alt: Icon

Share product drawing and step files with vendors and link them in the workorder tablet view.

Usage
~~~~~

Clone module into Odoo addon directory.

.. code-block:: bash

    git clone git@github.com:mint-system/odoo-app-mrp-documents-share.git ./addons/mrp_documents_share