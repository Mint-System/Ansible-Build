Go to company record and set a logo. Can see/modify applied colors on the "Navbar" section.

For optimal results use images with alpha channel.
