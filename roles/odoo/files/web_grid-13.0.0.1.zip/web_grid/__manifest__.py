# -*- coding: utf-8 -*-
{
    'name': "Grid View",

    'summary': "Basic 2D Grid view for odoo",
    'description': """
    """,
    'category': 'Hidden',

    'version': '0.1',

    'depends': ['web'],

    'data': ['views/templates.xml'],
    'qweb': ['static/src/xml/grid_view.xml'],
    'auto_install': True,
    'license': 'OEEL-1',
}
